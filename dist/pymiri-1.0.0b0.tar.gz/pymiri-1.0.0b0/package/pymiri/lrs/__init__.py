#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Dec 17 10:49:14 2025

@author: sshenoy
"""

"""This is the initialization for lrs module."""
